#!/usr/bin/env bash
set -euo pipefail

VERSION="0.2.95"
COMMIT="301f2b0c4d44e741a772d23b77b0868dce04f779"
APPDIR="$HOME/Downloads/ArtinSentinel_Hikvision_0295"
URL="https://codeload.github.com/artin-master/ArtinSentinel/zip/$COMMIT"

echo "Artin Sentinel $VERSION — Hikvision Playback/Export"
echo "Candidata de campo"
echo

if ! command -v python3 >/dev/null 2>&1; then
  echo "ERRO: Python 3 não está instalado."
  exit 1
fi

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

echo "Baixando o pacote da versão $VERSION..."
python3 - "$URL" "$TMP/source.zip" <<'PY'
import sys, urllib.request
url, target = sys.argv[1], sys.argv[2]
request = urllib.request.Request(url, headers={"User-Agent": "Artin-Sentinel-Installer/0.2.95"})
with urllib.request.urlopen(request, timeout=90) as response, open(target, "wb") as out:
    while True:
        chunk = response.read(1024 * 1024)
        if not chunk:
            break
        out.write(chunk)
PY

echo "Extraindo..."
python3 - "$TMP/source.zip" "$TMP/src" <<'PY'
import sys, zipfile, pathlib
archive, destination = sys.argv[1], pathlib.Path(sys.argv[2])
destination.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(archive) as z:
    z.extractall(destination)
PY

SRC="$(find "$TMP/src" -mindepth 1 -maxdepth 1 -type d | head -n1)"
if [[ -z "${SRC:-}" || ! -f "$SRC/install.sh" ]]; then
  echo "ERRO: pacote baixado inválido."
  exit 1
fi

echo "Validando a versão..."
python3 - "$SRC" <<'PY'
import sys, pathlib
root = pathlib.Path(sys.argv[1])
checks = {
    "pyproject": 'version = "0.2.95"' in (root / "pyproject.toml").read_text(encoding="utf-8"),
    "package": '__version__ = "0.2.95"' in (root / "artin_sentinel" / "__init__.py").read_text(encoding="utf-8"),
    "installer": 'NEW_VERSION="0.2.95"' in (root / "install.sh").read_text(encoding="utf-8"),
}
bad = [k for k, ok in checks.items() if not ok]
if bad:
    raise SystemExit("ERRO: versão do pacote não confere: " + ", ".join(bad))
print("Versão 0.2.95 confirmada.")
PY

rm -rf "$APPDIR"
mkdir -p "$(dirname "$APPDIR")"
cp -a "$SRC" "$APPDIR"

cd "$APPDIR"
chmod +x install.sh

echo
echo "Executando o instalador normal do Artin Sentinel..."
exec ./install.sh
